function validateLogin() {
  var user = document.forms["login"]["username"];
  var pass = document.forms["login"]["password"];

  	if (user.value == "") {
    document.getElementById("user").innerHTML="**Please enter valid user";
    return false;
	}
	else{
	document.getElementById("user").innerHTML="";
    return false;
	}
	if (name.value < 3) {
    document.getElementById("user").innerHTML="**Username should have more than three characters";
    return false;
	}
	else{
	document.getElementById("user").innerHTML="";
    return false;
	}
	if (pass.value == "") {
    document.getElementById("password").innerHTML="**Please enter your password ";
    return false;
	}
	if (pass.value.length>=3 || pass.value.length<20 ){
		document.getElementById("password").innerHTML="**Password should be more than 3 characters and less than 20";
    return false;
	}
	
}	

function validateHome() {
  var emailHomej = document.forms["home"]["emailH"];

  	if (emailHomej.value == "") {
    document.getElementById("emailHome").innerHTML="**Please enter your email";
    return false;
	}
	else{
	document.getElementById("emailHome").innerHTML="";
    return false;
	}
	if (emailHomej.value.indexOf('@') <= 0) {
    document.getElementById("emailHome").innerHTML="**invalid email";
    return false;
	}
	else{
	document.getElementById("emailHome").innerHTML="";
    return false;
	}
	if ((emailHomej.value.charAt(emailHomej.value.length-4)!='.') && (emailHomej.value.charAt(emailHomej.value.length-3)!='.')) {
    document.getElementById("emailHome").innerHTML="**invalid domain";
    return false;
	}
	else{
	document.getElementById("emailHome").innerHTML="";
    return false;
	}
	 
}	

function validateContact() {
  var fname = document.forms["contact"]["firstName"];
  var lname = document.forms["contact"]["lastName"];
  var tele = document.forms["contact"]["phoneNumber"];
  var msg = document.forms["contact"]["message"];

  	if (fname.value == "") {
    document.getElementById("fn").innerHTML="**Please enter your first name";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (fname.value < 3) {
    document.getElementById("fn").innerHTML="**First name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (lname.value == "") {
    document.getElementById("ln").innerHTML="**Please enter your last name";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (lname.value < 3) {
    document.getElementById("ln").innerHTML="**Last name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (tele.value == "") {
    document.getElementById("tel").innerHTML="**Please enter your telephone number";
    return false;
	}
	else{
	document.getElementById("tel").innerHTML="";
    return false;
	}
	if (isNaN(tele.value)) {
    document.getElementById("tel").innerHTML="**Telephone number should have only digits";
    return false;
	}
	else{
	document.getElementById("tel").innerHTML="";
    return false;
	}
	if (tele.value.length!=10) {
    document.getElementById("tel").innerHTML="**Telephone number should have 10 digits";
    return false;
	}
	else{
	document.getElementById("tel").innerHTML="";
    return false;
	}
	if (msg.value == "") {
    document.getElementById("tmessage").innerHTML="**Please enter your message";
    return false;
	}
	else{
	document.getElementById("tmessage").innerHTML="";
    return false;
	}
	if (msg.value < 3) {
    document.getElementById("tmessage").innerHTML="**Message should have more than three characters";
    return false;
	}
	else{
	document.getElementById("tmessage").innerHTML="";
    return false;
	}
	 
}

function validatesignup() {
  var name = document.forms["signup"]["name"];
  var lname = document.forms["signup"]["lname"];
  var email = document.forms["signup"]["email"];
  var user = document.forms["signup"]["user"];
  var pass = document.forms["signup"]["password"];
  
  	if (name.value == "") {
    document.getElementById("name").innerHTML="**Please enter your first name";
    return false;
	}
	else{
	document.getElementById("name").innerHTML="";
    return false;
	}
	if (name.value < 3) {
    document.getElementById("name").innerHTML="**First name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("name").innerHTML="";
    return false;
	}
	if (lname.value == "") {
    document.getElementById("lname").innerHTML="**Please enter your last name";
    return false;
	}
	else{
	document.getElementById("lname").innerHTML="";
    return false;
	}
	if (lname.value < 3) {
    document.getElementById("lname").innerHTML="**Last name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("lname").innerHTML="";
    return false;
	}
	if (user.value == "") {
    document.getElementById("user").innerHTML="**Please enter valid user";
    return false;
	}
	else{
	document.getElementById("user").innerHTML="";
    return false;
	}
	if (name.value < 3) {
    document.getElementById("user").innerHTML="**Username should have more than three characters";
    return false;
	}
	else{
	document.getElementById("user").innerHTML="";
    return false;
	}
  	if (email.value == "") {
    document.getElementById("email").innerHTML="**Please enter your email";
    return false;
	}
	else{
	document.getElementById("email").innerHTML="";
    return false;
	}
	if (email.value.indexOf('@') <= 0) {
    document.getElementById("email").innerHTML="**invalid email";
    return false;
	}
	else{
	document.getElementById("email").innerHTML="";
    return false;
	}
	if ((email.value.charAt(email.value.length-4)!='.') && (email.value.charAt(email.value.length-3)!='.')) {
    document.getElementById("email").innerHTML="**invalid domain";
    return false;
	}
	else{
	document.getElementById("email").innerHTML="";
    return false;
	}
	if (pass.value == "") {
    document.getElementById("password").innerHTML="**Please enter your password ";
    return false;
	}
	else{
	document.getElementById("password").innerHTML="";
    return false;
	}
	if (pass.value.length>=3 || pass.value.length<20 ){
		document.getElementById("password").innerHTML="**Password must be at least 4 characters, no more than 8 characters, and must include at least one upper case letter, one lower case letter, and one numeric digit";
    return false;
	}
	else{
	document.getElementById("password").innerHTML="";
    return false;
	}
	
}

function validateBusiness() {
  var lname = document.forms["business"]["lastName"];
  var email = document.forms["business"]["email"];
  var pass = document.forms["business"]["password"];
  
  	
	if (lname.value == "") {
    document.getElementById("ln").innerHTML="**Please enter your last name";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (lname.value < 3) {
    document.getElementById("ln").innerHTML="**Last name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
  	if (email.value == "") {
    document.getElementById("emails").innerHTML="**Please enter your email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if (email.value.indexOf('@') <= 0) {
    document.getElementById("emails").innerHTML="**invalid email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if ((email.value.charAt(email.value.length-4)!='.') && (email.value.charAt(email.value.length-3)!='.')) {
    document.getElementById("emails").innerHTML="**invalid domain";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if (pass.value == "") {
    document.getElementById("passwords").innerHTML="**Please enter your password ";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	if (pass.value.length>=3 || pass.value.length<20 ){
		document.getElementById("passwords").innerHTML="**Password should be more than 3 characters and less than 20";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	
}

function validateIndividual() {
  var fname = document.forms["individual"]["firstName"];
  var lname = document.forms["individual"]["lastName"];
  var email = document.forms["individual"]["email"];
  var pass = document.forms["individual"]["password"];
  var work = document.forms["individual"]["work"];
  var school = document.forms["individual"]["school"];
  
  	if (fname.value == "") {
    document.getElementById("fn").innerHTML="**Please enter your first name";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (fname.value < 3) {
    document.getElementById("fn").innerHTML="**First name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (lname.value == "") {
    document.getElementById("ln").innerHTML="**Please enter your last name";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (lname.value < 3) {
    document.getElementById("ln").innerHTML="**Last name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (work.value == "") {
    document.getElementById("work").innerHTML="**Please enter your work name";
    return false;
	}
	else{
	document.getElementById("work").innerHTML="";
    return false;
	}
	if (work.value < 3) {
    document.getElementById("work").innerHTML="**Work name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("work").innerHTML="";
    return false;
	}
	if (school.value == "") {
    document.getElementById("school").innerHTML="**Please enter your school name";
    return false;
	}
	else{
	document.getElementById("school").innerHTML="";
    return false;
	}
	if (school.value < 3) {
    document.getElementById("school").innerHTML="**School name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("school").innerHTML="";
    return false;
	}
  	if (email.value == "") {
    document.getElementById("emails").innerHTML="**Please enter your email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if (email.value.indexOf('@') <= 0) {
    document.getElementById("emails").innerHTML="**invalid email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if ((email.value.charAt(email.value.length-4)!='.') && (email.value.charAt(email.value.length-3)!='.')) {
    document.getElementById("emails").innerHTML="**invalid domain";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if (pass.value == "") {
    document.getElementById("passwords").innerHTML="**Please enter your password ";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	if (pass.value.length>=3 || pass.value.length<20 ){
		document.getElementById("passwords").innerHTML="**Password should be more than 3 characters and less than 20";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	
}

function validateProfile() {
  var fname = document.forms["profile"]["firstName"];
  var lname = document.forms["profile"]["lastName"];
  var email = document.forms["profile"]["email"];
  var pass = document.forms["profile"]["password"];
  var changePass = document.forms["profile"]["changePassword"];
  var work = document.forms["profile"]["work"];
  var school = document.forms["profile"]["school"];
  
  	if (fname.value == "") {
    document.getElementById("fn").innerHTML="**Enter";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (fname.value < 3) {
    document.getElementById("fn").innerHTML="**First name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("fn").innerHTML="";
    return false;
	}
	if (lname.value == "") {
    document.getElementById("ln").innerHTML="**Enter";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (lname.value < 3) {
    document.getElementById("ln").innerHTML="**Last name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("ln").innerHTML="";
    return false;
	}
	if (work.value == "") {
    document.getElementById("work").innerHTML="**Please enter your work name";
    return false;
	}
	else{
	document.getElementById("work").innerHTML="";
    return false;
	}
	if (work.value < 3) {
    document.getElementById("work").innerHTML="**Work name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("work").innerHTML="";
    return false;
	}
	if (school.value == "") {
    document.getElementById("school").innerHTML="**Please enter your school name";
    return false;
	}
	else{
	document.getElementById("school").innerHTML="";
    return false;
	}
	if (school.value < 3) {
    document.getElementById("school").innerHTML="**School name should have more than three characters";
    return false;
	}
	else{
	document.getElementById("school").innerHTML="";
    return false;
	}
  	if (email.value == "") {
    document.getElementById("emails").innerHTML="**Please enter your email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if (email.value.indexOf('@') <= 0) {
    document.getElementById("emails").innerHTML="**invalid email";
    return false;
	}
	else{
	document.getElementById("emails").innerHTML="";
    return false;
	}
	if ((email.value.charAt(email.value.length-4)!='.') && (email.value.charAt(email.value.length-3)!='.')) {
    document.getElementById("emails").innerHTML="**invalid domain";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	if (pass.value == "") {
    document.getElementById("passwords").innerHTML="**Please enter your password ";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	if (pass.value.length>=3 || pass.value.length<20 ){
		document.getElementById("passwords").innerHTML="**Password should be more than 3 characters and less than 20";
    return false;
	}
	else{
	document.getElementById("passwords").innerHTML="";
    return false;
	}
	if (changePass.value == "") {
    document.getElementById("cpasswords").innerHTML="**Please change your password ";
    return false;
	}
	else{
	document.getElementById("cpasswords").innerHTML="";
    return false;
	}
	if (changePass.value.length>=3 || changePass.value.length<20 ){
		document.getElementById("cpasswords").innerHTML="**Password should be more than 3 characters and less than 20";
    return false;
	}
	else{
	document.getElementById("cpasswords").innerHTML="";
    return false;
	}
	
}