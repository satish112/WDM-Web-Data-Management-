<?php include('signup2.php') ?> 
<?php 
session_start();
if (!isset($_SESSION['username']) || $_SESSION['username'] == ''){
  echo "<script type=\"text/javascript\">alert('Please login to SEE other pages');";
  echo "window.location.href = 'guesthome.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="./css/hire.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">HIRE ME</span>
</div>
<?php
    //execute the SQL query and return records
    $query = "select * FROM hireme";
    $result = mysqli_query($db, $query);
 ?>
<div class="table"> 
    <div class="row">
        <?php while ($row = $result->fetch_assoc()) {
        echo'<div class="column">
                <img src="uploads/'.$row['name'].'" alt="" class="img-responsive" >
                    <h2>'.$row['rate'].'</h2>
                <p>'.$row['input1'].'<br/> '.$row['input2'].'<br/> '.$row['input3'].'<br/> '.$row['input4'].'</p>
	            <hr>
	            <a href="contact.php"><button class="btn">Contact Us</button></a>
	       </div>';
        }?>
    </div>
</div>
<div class="arrow">
<a href="Home.php"><i class="icon fa fa-arrow-up"></i></a>
</div>
<style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
.table{
        display: table;         
  width: auto; 
border-spacing: 50px;  
}
.column {
  float: left;
  width: 33.33%;
  height:600px;
  display:table-column;     
}
.column img {
height: 180px;
width: 350px;
}
.row {
padding-top: 80px;
display: table-row;
  width: auto;
  clear: both;
}
.arrow{
  width: auto;
  height: auto; 
  padding-left:auto;
  padding-top: auto;
}
</style>
</center>
</body>
</html>
