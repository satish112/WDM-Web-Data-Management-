<?php
session_start();
      
      // initializing variables

      $servername = "localhost";
      $database = "satishre_website";
      $username = "satishre_sxr7996";
      $password = "Padma123@6";
      $errors = array();

      // Create connection

      $db = mysqli_connect($servername, $username, $password, $database);

      // Check connection

      if (!$db) {

          die("Connection failed: " . mysqli_connect_error());

      }
      
      // REGISTER USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $lname = mysqli_real_escape_string($db, $_POST['lname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $user = mysqli_real_escape_string($db, $_POST['user']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  $repeatpassword = mysqli_real_escape_string($db, $_POST['repeatpassword']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($name)) { array_push($errors, "name is required"); }
  if (empty($lname)) { array_push($errors, "lname is required"); }
  if (empty($email)) { array_push($errors, "email is required"); }
  if (empty($user)) { array_push($errors, "user is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password!= $repeatpassword) {
  array_push($errors, "The two passwords do not match");
  }

// first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE user='$user' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user1 = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['user'] === $user1) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }
// Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
    $password = md5($password);//encrypt the password before saving in the database
    $query = "INSERT INTO users (name, lname, email, user, password) 
          VALUES('$name', '$lname','$email', '$user', '$password')";
    mysqli_query($db, $query);
    $_SESSION['user'] = $user;
    $_SESSION['success'] = "You are now logged in";
    header('location: login.php');
  }
}
if (isset($_POST['adminsubmit'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $lname = mysqli_real_escape_string($db, $_POST['lname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $user = mysqli_real_escape_string($db, $_POST['user']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  $repeatpassword = mysqli_real_escape_string($db, $_POST['repeatpassword']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($name)) { array_push($errors, "name is required"); }
  if (empty($lname)) { array_push($errors, "lname is required"); }
  if (empty($email)) { array_push($errors, "email is required"); }
  if (empty($user)) { array_push($errors, "user is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password!= $repeatpassword) {
  array_push($errors, "The two passwords do not match");
  }

// first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM admin WHERE user='$user' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user1 = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['user'] === $user1) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }
// Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
    $password = md5($password);//encrypt the password before saving in the database
    $query = "INSERT INTO admin (name, lname, email, user, password) 
          VALUES('$name', '$lname','$email', '$user', '$password')";
    mysqli_query($db, $query);
    $_SESSION['user'] = $user;
    $_SESSION['success'] = "You are now logged in";
    header('location: adminlogin.php');
  }
}
if (isset($_POST['login'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM users WHERE user='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: Home.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}
if (isset($_POST['adminlogin'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM admin WHERE user='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: adminhome.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}
if (isset($_POST['save'])) { // if save button on the form is clicked
    // name of the uploaded file
    $filename = $_FILES['myfile']['name'];

    // destination of the file on the server
    $destination = 'uploads/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "<script type=\"text/javascript\">alert('You file extension must be .zip, .pdf or .docx');</script>";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO home (name, size, downloads) VALUES ('$filename', $size, 0)";
            if (mysqli_query($db, $sql)) {
                echo "<script type=\"text/javascript\">alert('Uploaded Successfully!');</script>";
            }
        } else {
            echo "<script type=\"text/javascript\">alert('Failed to upload');</script>";
        }
    }
}
if (isset($_POST['download'])) {

    // fetch file to download from database
    $sql = "SELECT * FROM home ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($db, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'uploads/' . $file['name'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('uploads/' . $file['name']));
        readfile('uploads/' . $file['name']);

        // Now update downloads count
        $newCount = $file['downloads'] + 1;
        $id = $file['id'];
        $updateQuery = "UPDATE home SET downloads=$newCount WHERE id= $id";
        mysqli_query($db, $updateQuery);
        exit;
    }

}
if (isset($_POST['send_message_btn'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $subject = $_POST['phone'];
  $msg = $_POST['message'];
  // Content-Type helps email client to parse file as HTML 
  // therefore retaining styles
  $headers = "MIME-Version: 1.0" . "\r\n";
  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
  $message = "<html>
  <head>
  	<title>New message from website contact form</title>
  </head>
  <body>
  	<h1>" . $name . "</h1>
  	<h2>".$email."</h2>
  	<h3>".$subject."</h3>
  	<p>".$msg."</p>
  </body>
  </html>";
  if (mail('satish.rella111@gmail.com', $name, $message, $headers)) {
   echo "<script type=\"text/javascript\">alert('Email Sent');</script>";
  }else{
   echo "<script type=\"text/javascript\">alert('Failed to send');</script>";
  }
}
if (isset($_POST['insert'])) { // if insert button on the form is clicked
    // name of the uploaded file
    $file_get = $_FILES['foto']['name'];
    $temp = $_FILES['foto']['tmp_name'];
    $rate = mysqli_real_escape_string($db, $_POST['rate']);
    $input1 = mysqli_real_escape_string($db, $_POST['input1']);
    $input2 = mysqli_real_escape_string($db, $_POST['input2']);
    $input3= mysqli_real_escape_string($db, $_POST['input3']);
    $input4 = mysqli_real_escape_string($db, $_POST['input4']);
    $file_to_saved = "uploads/".$file_get;
    move_uploaded_file($temp, $file_to_saved);
    $query = "INSERT INTO hireme (name, rate, input1, input2, input3, input4) 
          VALUES('$file_get', '$rate','$input1', '$input2', '$input3', '$input4')";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Inserted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Insertion failed, try again');</script>";
            }
}
if (isset($_POST['update'])) { // if update button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['cartnumber']);
    $input = mysqli_real_escape_string($db, $_POST['input']);
    $newvalue = mysqli_real_escape_string($db, $_POST['newvalue']);
    $query = "UPDATE hireme SET $input = '$newvalue' WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Updated Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Updation failed, try again');</script>";
            }
}
if (isset($_POST['delete'])) { // if delete button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['cartnumber']);
    $query = "DELETE FROM hireme WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Deleted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Deletion failed, try again');</script>";
            }
}
if (isset($_POST['resumeinsert'])) { // if insert button on the form is clicked
    // name of the uploaded file
    $year = mysqli_real_escape_string($db, $_POST['year']);
    $employer = mysqli_real_escape_string($db, $_POST['employer']);
    $position = mysqli_real_escape_string($db, $_POST['position']);
    $query = "INSERT INTO resume (some, employer, position) 
          VALUES('$year', '$employer','$position')";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Inserted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Insertion failed, try again');</script>";
            }
}
if (isset($_POST['resumeupdate'])) { // if update button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['fieldnumber']);
    $input = mysqli_real_escape_string($db, $_POST['input']);
    $newvalue = mysqli_real_escape_string($db, $_POST['newvalue']);
    $query = "UPDATE resume SET $input = '$newvalue' WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Updated Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Updation failed, try again');</script>";
            }
}
if (isset($_POST['resumedelete'])) { // if delete button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['cartnumber']);
    $query = "DELETE FROM resume WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Deleted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Deletion failed, try again');</script>";
            }
}
if (isset($_POST['skillsinsert'])) { // if insert button on the form is clicked
    // name of the uploaded file
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $percentage = mysqli_real_escape_string($db, $_POST['percentage']);
    $color = mysqli_real_escape_string($db, $_POST['colour']);
    $icon = mysqli_real_escape_string($db, $_POST['icon']);
     $query = "INSERT INTO skills (skillname, skillpercentage, skillcolor, skillicon) 
          VALUES('$name', '$percentage','$color','$icon')";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Inserted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Insertion failed, try again');</script>";
            }
}
if (isset($_POST['skillsupdate'])) { // if update button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['fieldnumber']);
    $input = mysqli_real_escape_string($db, $_POST['input']);
    $newvalue = mysqli_real_escape_string($db, $_POST['newvalue']);
    $query = "UPDATE skills SET $input = '$newvalue' WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Updated Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Updation failed, try again');</script>";
            }
}
if (isset($_POST['skillsdelete'])) { // if delete button on the form is clicked
    // receiving inputs from the form
    $cartnumber = mysqli_real_escape_string($db, $_POST['cartnumber']);
    $query = "DELETE FROM skills WHERE id = $cartnumber";
    
    if (mysqli_query($db, $query)) {
                echo "<script type=\"text/javascript\">alert('Deleted Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Deletion failed, try again');</script>";
            }
}
if (isset($_POST['aboutupdate']))
          {
			$name =   $_POST['name'];
			$email=   $_POST['email'];
		    $phone =  $_POST['phone'];
		    
			$address = $_POST['address'];
			$nationality = $_POST['nationality'];
		    $dob = $_POST['dob'];
			$description= $_POST['description'];
		
			$sql= "UPDATE about SET name = '$name', email = '$email', phone= '$phone', address = '$address', dob= '$nationality', description='$description'";
			
			if (mysqli_query($db, $sql)) {
                echo "<script type=\"text/javascript\">alert('Updated Successfully!');</script>";
            }
            else{
                echo"<script type=\"text/javascript\">alert('Updation failed, try again');</script>";
            }
}
			
  ?>
