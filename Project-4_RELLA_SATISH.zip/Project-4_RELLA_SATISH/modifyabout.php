<?php include('signup2.php') ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>
<center>
<h2>MODIFY ABOUT PAGE</h2>

<?php
    //execute the SQL query and return records
    $query = "select * FROM about";
    $result = mysqli_query($db, $query);
 ?>

<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Modify</button>

</center>
<div id="id01" class="modal">
  
  <form class="modal-content animate" action="modifyabout.php" method="post" enctype="multipart/form-data">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>
    <center><h2> Modify About Page Fields </h2></center>

    <div class="container">
        <?php
      while ($row = $result->fetch_assoc())
{
   $image = $row['image'];
   $name = $row['name'];
   $email = $row['email'];
   $phone = $row['phone'];
   $address = $row['address'];
   $nationality = $row['nationality'];
   $dob = $row['dob'];
   $description = $row['description'];
}?>

       
      <label for="text"><b>Name</b></label>
      <input type="text" name="name" value ="<?php echo $name?>" class="boxprop">

      <label for="text"><b>Email</b></label>
      <input type="text" name="email" value ="<?php echo $email?>" class="boxprop">
      
      <label for="text"><b>Phone</b></label>
      <input type="text" name="phone" value ="<?php echo $phone?>" class="boxprop">
      
      <label for="text"><b>Address</b></label>
      <input type="text" name="address" value ="<?php echo $address?>" class="boxprop">
      
      <label for="text"><b>Nationality</b></label>
      <input type="text" name="nationality" value ="<?php echo $nationality?>" class="boxprop">
      
      <label for="text"><b>Date of Birth</b></label>
      <input type="text" name="dob" value ="<?php echo $dob?>" class="boxprop">
      
      <label for="text"><b>Description</b></label>
      <input type="text" name="description" value ="<?php echo $description?>" class="boxprop">
        
      <button type="submit" name="aboutupdate">Modify</button>
      
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<div class="arrow">
        <a href="adminhome.php"><i class="icon fa fa-arrow-up"></i></a>
      </div>
<style>
    .fa-arrow-up {
  font-size: 20px;
  background: black;
  color: blue;
   padding:15px;
   padding-right: 15px;
   padding-left: 15px;
   float:right;
}
.arrow{

  padding:600px;
padding-top:50px;
}
</style>
</body>
</html>