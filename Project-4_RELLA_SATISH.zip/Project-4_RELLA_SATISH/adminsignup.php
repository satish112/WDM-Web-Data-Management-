<?php include('signup2.php') ?> 
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="./css/signup.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="validation.js"></script>
</head>
<body>
<form name="signup" action="adminsignup.php" id= "register" method="post" style="border:1px solid #ccc">
    <?php include('errors.php') ?>
  <div class="container">
      <h1>Admin check in</h1>
    <hr>
    <label for="Name"><b>Name:</b></label>
    <input type="text" id="name"  name="name" required pattern="[a-zA-Z]{3,}" title="Enter more than three letters" >

    <label for="Last Name"><b>Last Name:</b></label>
    <input type="text" id="lname" name="lname" required pattern="[a-zA-Z]{3,}" title="Enter more than three letters">

    <label for="email"><b>Email:</b></label>
    <input type="text" id="email" name="email" required  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="Enter valid email">


    <label for="user"><b>User:</b></label>
    <input type="text" id="user" name="user" required pattern="[a-zA-Z0-9]{3,}" title="Enter more than three letters">


    <label for="psw"><b>Password:</b></label>
    <input type="password" id="password" name="password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$" title="Enter 4-8, one upper,lower and numeric">

    <label for="psw-repeat"><b>Repeat Password:</b></label>
    <input type="password" id="repeatpassword" name="repeatpassword" required>
    </hr>
    <div class="clearfix">
      <button type="button" class="btn">Close</button>
      <button type="submit" name="adminsubmit" value="submit" class="btn"onclick="validatesignup()">Save</button>
    </div>
  </div>
  <div class="arrow">
        <a href="guesthome.php"><i class="icon fa fa-arrow-up"></i></a>
      </div>
      <style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
</style>
</form>
</body>
</html>
