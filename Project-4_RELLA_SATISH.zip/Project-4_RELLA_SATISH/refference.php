<?php include('signup2.php') ?> 
<?php 
session_start();
if (!isset($_SESSION['username']) || $_SESSION['username'] == ''){
  echo "<script type=\"text/javascript\">alert('Please login to SEE other Pages');";
  echo "window.location.href = 'guesthome.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/reference.css">
</head>
<body>
<center>
<div style="width: 100%; height: 10px; border-bottom: 1px solid #D0D0D0; text-align: center;  padding-top: 25px;" >
  <span style="font-size: 15px; background-color: white; border: 2px solid #0066FF; padding: 10px 20px;">
    REFERENCES
  </span>
</div>
<div class="row">
  <div class="column">
    <div id = "border">
      <img src="./images/joe.jpg" alt="Avatar" width="50" height="50" align="center" >
      <h4>JOE RODRIGUEZ</h4>
      <h6>DEVELOPER/MUSICIAN</h6>
      <p>"As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."  </p>
    </div>    
  </div>
  <div class="column" >
    <div id ="border">
      <img src="./images/rosy.jpg"alt="Avatar" width="50" height="50"/>
      <h4>ROSY CORONADO</h4>
      <h6>PSYCHOLOGIST</h6>
      <p>As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."</p>
    </div>
  </div>
  <div class="column" >
    <div id="border">

      <img src="./images/yury.jpg"alt="Avatar" width="50" height="50"/>
      <h4>YURY JAJITZKY</h4>
      <h6>CEO / DEVELOPER</h6>
      <p>As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."</p>
    </div>
  </div>
   <div class="column">
    <div id ="border">
      <img src="./images/kyss.jpg"alt="Avatar" width="50" height="50"/>
      <h4>KYSS CHIRINOS</h4>
      <h6> MARKETING / DESIGNER</h6>
      <p>As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."</p>
    </div>
  </div>
  <div class="column" >
    <div id ="border">

      <img src="./images/carhil.jpg"alt="Avatar" width="50" height="50"/>
      <h4>CARHIL MATOS</h4>
      <h6> CEO / DEVELOPER </h6>
      <p>As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."</p>
    </div>
  </div>
  <div class="column" >
    <div id ="border">
      <img src="./images/leo.jpg"alt="Avatar" width="50" height="50"/>
      <h4>MARK ZUKERBERG</h4>
      <h6> MARKETING / DESIGNER / MUSICIAN. </h6>
      <p>As always, great creative thinking for the best solution.Luis Miguel is by far the most professional and 
        knowledgeable provider i worked with. I will hire him again :)"."</p>
    </div>
    <div class="arrow">
        <a href="Home.php"><i class="icon fa fa-arrow-up"></i></a>
      </div>
  </div>
</div>
</center>
</body>
</html>
