<?php include('signup2.php') ?> 
<?php 
session_start();
if (!isset($_SESSION['username']) || $_SESSION['username'] == ''){
  echo "<script type=\"text/javascript\">alert('Please login to SEE other pages');";
  echo "window.location.href = 'guesthome.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/portfolio.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">PORTFOLIO</span>
</div>
<div class="topnav">
  <div class="topnav-centered">
    <a href="#home" class="active">All</a>
    <a href="#home" class="active">Websites</a>
    <a href="#home" class="active">Apps</a>
    <a href="#home" class="active">Design</a>
    <a href="#home" class="active">Photography</a>
</div>
<div class="row">
  <div class="column">
    <img src="./images/asgardia.png" width="400px" height="250px" />
    <img src="./images/1.jpg" width="400px" height="600px"/>
    <img src="./images/app8.png" width="400px" height="600px"/>
    <img src="./images/app5.png" width="400px" height="600px"/>
  </div>
  <div class="column">
    <img src="./images/dise11.jpg" width="400px" height="400px" />
    <img src="./images/app9.png" width="400px" height="700px"/>
    <img src="./images/app7.png" width="400px" height="700px"/>
    <img src="./images/player.png" width="400px" height="250px"/>
  </div>
  <div class="column">
    <img src="./images/16.jpg" width="400px" height="650px" />
    <img src="./images/dise4.png" width="410px" height="450px"/>
    <img src="./images/9.jpg" width="400px" height="600px"/>
    <img src="./images/dise5.png" width="400px" height="250px"/>
    <a href="Home.php"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>