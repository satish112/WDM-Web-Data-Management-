<?
session_start();
session_unset();
header("location:guesthome.php");

?>