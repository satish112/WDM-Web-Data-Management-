<?php include('signup2.php') ;
 session_start();
 
 $_SESSION['username'] = $username;
 ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/home.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
</head>
<body>
	<div id="sidebar">
		<center> <img src="./images/logo.png"/> </center>
		<center> <img src="./images/name.jpeg"/> </center>
  		<ul>
			<li><a style="color:white" href="Home.php">HOME</a></li>
		    <li><a style="color:white" href="about.php">ABOUT</a></li>
			<li><a style="color:white" href="skills.php">SKILLS</a></li>
			<li><a style="color:white" href="resume.php">RESUMES</a></li>
			<li><a style="color:white" href="portfolio.php">PORTFOLIO</a></li>
			<li><a style="color:white" href="http://satishrella.uta.cloud/porject-2/">BLOG</a></li>
			<li><a style="color:white" href="hire.php">HIRE ME</a></li>
			<li><a style="color:white" href="refference.php">REFERENCES</a></li>
			<?php if ($_SESSION['username'] == $username) : ?>
			<li><a style="color:white" href="logout.php">LOGOUT</a></li>
			<?php else : ?> 
			<li><a style="color:white" href="login.html	"></i>LOG IN</a></li>
			<li><a style="color:white" href="signup.html">SIGN UP</a></li>
			<?php endif;?>
			<p style="font-size: 12px; color: white"> &#169; DiazApps ALL RIGHTS RESERVED BY<span style="color: blue; font-size: 12px">Luis M Alvarez</span></p>
		</ul>
	</div>
	<div class="bg" style="float:right; width:85% ">
  		<div id="content">
    		<p style="font-size:35px; padding-left:80px;">HELLO I'M</p>
    		<p style="font-size:70px; padding-left:80px;">LUIS MIGUEL ALVAREZ</p>
    		<p style="font-size:35px; padding-left:80px;">MOBILE DEVELOPER</p>
    		<form action="Home.php" method="post" enctype="multipart/form-data" >
    		<button class="btn" style="position: absolute; left: 80px;" type="submit" name="download"> Download My CV <i class="fa fa-download"></i></button>
    	   </form>

    		<style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
</style>
  		</div>
	</div>
</body>
</html>
