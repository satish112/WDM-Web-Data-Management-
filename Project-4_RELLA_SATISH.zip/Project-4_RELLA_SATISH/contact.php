<?php include('signup2.php') ?> 
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/contact.css">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">CONTACT ME</span>
</div>
</center>
<div class="row">
  <div class="column">
    <h2>CONTACT ADDRESS</h2>
    <p><i class="fa fa-map-marker"></i>&nbsp;<strong>Address:</strong> 635 Elraml, South CornerStret, Alexandria, Egypt<br/>
	<i class="fa fa-phone"></i>&nbsp;<strong>Phone:</strong> +20 012 345 6789<br/>
	<i class="fa fa-whatsapp"></i>&nbsp;<strong>Whatsapp:</strong> +20 012 859 7859<br/>
	<i class="fa fa-skype"></i>&nbsp;<strong>Skype:</strong>e.example<br/> 
	<i class="fa fa-envelope-o"></i>&nbsp;<strong>Email:</strong> <a href="#" class="link">luismalvarez@website.com </a> <br/>
	<i class="fa fa-home"></i>&nbsp;<strong>Website:</strong>  <a href="#" class="link">www.website.com </a> <br/>
  </p>
  <div>
    <a href="#" class="fa fa-facebook"></a>
    <a href="#" class="fa fa-twitter"></a>
	<a href="#" class="fa fa-linkedin"></a>
	<a href="#" class="fa fa-pinterest"></a>
	<a href="#" class="fa fa-google-plus"></a>
	<a href="#" class="fa fa-snapchat"></a>        
    </div>
    
  </div>
  <div class="column" >
    <h2>LET'S HAVE A FUN</h2>
    <form method="post" action="contact.php">
    <input placeholder="Your Name" type="text" name="name" /><br/>
	<input placeholder="Email" type="text" name="email" required  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="Enter valid email"/><br/>
	<input placeholder="Phone" type="text" name="phone" required  pattern="^[2-9]\d{2}-\d{3}-\d{4}$" title="Enter valid phone number"/><br/>
	<textarea placeholder="Your Message" rows="4" cols="50" name="message"></textarea>
	<br/>
	<button class="btn" name="send_message_btn" >Send Now</button>
	</form>
  <a href="Home.php"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>

  </div>
  <style>
      button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
  </style>

  
</body>
</html>
