<?php include('signup2.php') ?> 
<?php 
session_start();
if (!isset($_SESSION['username']) || $_SESSION['username'] == ''){
  echo "<script type=\"text/javascript\">alert('Please login to SEE other pages');";
  echo "window.location.href = 'guesthome.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php
    //execute the SQL query and return records
    $query = "select * FROM resume";
    $result = mysqli_query($db, $query);
 ?>
<center>
<div class="topbar" >
  <span class ="topbar">RESUMES</span>
</div> </center>
<div class="timeline" >
    <?php
    while ($row = $result->fetch_assoc()) {
        if ($row['id'] % 2){
        echo '<div class ="container right" >
    <div class="content1">
      <h2>'.$row['employer'].'-- '.$row['year'].'</h2>
	  </div>
	  <div class="content2">
      <p>'.$row['position'].'</p>
    </div> 
  </div>';
        }
        else{
            echo
            '<div class="container left">
    <div class="content1">
      <h2>'.$row['employer'].'--  '.$row['year'].'</h2>
	  </div>
	  <div class="content2">
      <p>'.$row['position'].'</p>
    </div> 
  </div>';
        }
    }
    ?>
</div>
<div class="arrow">
        <a href="Home.php"><i class="icon fa fa-arrow-up"></i></a>
      </div>
<style>
.topbar {
width: 95%; 
height: 10px; 
border-bottom: 1px solid #D0D0D0; 
text-align: center;  
padding-top: 20px;	
}
.topbar span{
	font-size: 16px;
	background-color: white;
	border: 2px solid #0066FF; 
	padding: 10px 20px;
	padding-bottom:3px;
	text-align: center;
	
}

* {
  box-sizing: border-box;
}

.timeline {
  position: relative;
  max-width: 1200px;
  margin: 5px auto;
  padding-top: 70px;
  
}

.timeline::after {
  content: '';
  position: absolute;
  width: 3px;
  background-color: #D0D0D0;
  top: 50px;
  bottom: 0;
  left: 50%;
  margin-left: -3px;
}

.container {
content:'';
  padding: 10px 40px;
  position: relative;
  background-color: inherit;
  width: 50%;
}
.container::after {
 content: '';
  position: absolute;
  width: 25px;
  height: 25px;
  right: -17px;
  background-color:#D0D0D0;
  border: 4px solid blue;
  top: 15px;
  border-radius: 50%;
  z-index: 1;
}
.left {
  left: 0;
}

.right {
  left: 50%;
}

.left::before {
  content: " ";
  height: 0;
  position: absolute;
  top: 22px;
  width: 0;
  z-index: 1;
  right: 30px;
  border: medium solid white;
  border-width: 10px 0 10px 10px;
  border-color: transparent transparent transparent blue;
}

.right::before {
  content: '';
  height: 0;
  position: absolute;
  top: 22px;
  width: 0;
  z-index: 1;
  left: 30px;
  border: medium solid white;
  border-width: 10px 10px 10px 0;
  border-color: transparent blue transparent transparent;
}

.right::after {
  left: -16px;
}

.content1 {
height:40px;
	font-size: 10px;
  padding: 5px 6px;
  background-color: blue;
  position: relative;
  color: white;
}
.content2 {
height:40px;
	font-size: 12px;
  padding: 5px 6px;
  background-color: white;
  position: relative;
  border: solid #D0D0D0;
  border-top: none;
}

@media screen and (max-width: 600px) {
  .timeline::after {
  left: 31px;
  }
  .container {
  width: 100%;
  padding-left: 70px;
  padding-right: 25px;
  }
  .container::before {
  left: 60px;
  border: medium solid white;
  border-width: 10px 10px 10px 0;
  border-color: transparent white transparent transparent;
  }
  .left::after, .right::after {
  left: 15px;
  }
  .right {
  left: 0%;
  }
}

.fa-arrow-up {
  font-size: 20px;
  background: black;
  color: blue;
   padding:15px;
   padding-right: 15px;
   padding-left: 15px;
   float:right;
}
.arrow{

  width: 80%;
  height: 10; 
  padding-left:900px;
  padding-top: 0;
  float:right;
}
</style>
</body>
</html>
