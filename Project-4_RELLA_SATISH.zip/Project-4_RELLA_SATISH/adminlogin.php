<?php include('signup2.php') ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="./css/login.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="validation.js"></script>
</head>
<body>

<h2>Admin Login</h2>
<form name="login" action="adminlogin.php" method="post">
  <?php include('errors.php'); ?>
  <div class="container">
    <label for="uname"><b>User:</b></label>
    <input type="text" id="user"name="username" required pattern="[a-zA-Z0-9]{3,}" title="Enter more than three letters">
    <label for="psw"><b>Password:</b></label>
    <input type="password" id="password" name="password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$" title="Enter 4-8, one upper,lower and numeric">     
    <button type="submit" class="btn" name="adminlogin" onclick="validatelogin()">Get in</button>
    <button type="button" class="btn">Close</button>
  </div>
  <div class="arrow">
        <a href="guesthome.php"><i class="icon fa fa-arrow-up"></i></a>
      </div>
</form>
<style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
</style>

</body>
</html>
