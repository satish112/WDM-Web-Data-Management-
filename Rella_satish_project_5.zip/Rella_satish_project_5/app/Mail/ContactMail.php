<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Http\Request;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMail extends Mailable
{
    use Queueable, SerializesModels;

    public $email;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        //

        $request->validate([
          'email' => 'required',
          'name'=> 'required',
          'phone' => 'required',
          'content' => 'required',
        ]); 

        $this->email = $request;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('New Contact Mail')
                    ->from($this->email->email, $this->email->name,$this->email->phone)
                    ->to('satish.rella111@gmail.com')
                    ->view('email.contactmail');
    }
}
