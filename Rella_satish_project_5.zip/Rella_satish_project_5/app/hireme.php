<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hireme extends Model
{
    //
    protected $table = 'hiremes';
    protected $fillable =['name','rate','input1','input2','input3','input4'];
}
