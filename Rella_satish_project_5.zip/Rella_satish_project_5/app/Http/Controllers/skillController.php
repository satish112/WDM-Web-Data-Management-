<?php

namespace App\Http\Controllers;

use App\skills;

use Illuminate\Http\Request;

class skillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $skills = skills::all();
        return view('skills.index', compact('skills'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('skills.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $request->validate([
          'skillname' => 'required',
          'skillpercentage'=> 'required',
          'skillcolor' => 'required',
          'skillicon' => 'required',
        ]); 

        $skills= new skills();
        $skills->skillname=$request->get('skillname');
        $skills->skillpercentage=$request->get('skillpercentage');
        $skills->skillcolor=$request->get('skillcolor');
        $skills->skillicon=$request->get('skillicon');
        $skills->save();
        return redirect('/skills')->with('success', 'skill has added');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $skill = skills::find($id);
        return view('skills.edit',compact('skill','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $skill = skills::find($id);
          $skill->skillname=$request->get('skillname');
          $skill->skillpercentage=$request->get('skillpercentage');
          $skill->skillcolor=$request->get('skillcolor');
          $skill->skillicon=$request->get('skillicon');
          $skill->save();
          return redirect('skills');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $skill= skills::find($id);
        $skill->delete();
        return redirect('skills')->with('success','deleted successfully');
    }
}
