<?php

namespace App\Http\Controllers;

use App\resume;

use Illuminate\Http\Request;

class resumeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $resume = resume::all();
        return view('resumes.index', compact('resume'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('resumes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $resume= new resume();
        $resume->year=$request->get('year');
        $resume->employer=$request->get('employer');
        $resume->position=$request->get('position');
        $resume->save();
        return redirect('/resumes')->with('success', 'resume has added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $resume = resume::find($id);
        return view('resumes.edit',compact('resume','id'));
    }
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $resume = resume::find($id);
          $resume->year=$request->get('year');
          $resume->employer=$request->get('employer');
          $resume->position=$request->get('position');
          $resume->save();
          return redirect('resumes');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $resume= resume::find($id);
        $resume->delete();
        return redirect('resumes')->with('success','deleted successfully');
    }
}
