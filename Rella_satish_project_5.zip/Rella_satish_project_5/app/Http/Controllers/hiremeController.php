<?php

namespace App\Http\Controllers;

use App\hireme;

use Illuminate\Http\Request;

class hiremeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $hires = hireme::all();
        return view('hireme.index', compact('hires'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('hireme.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $hireme= new hireme();
        if($request->hasfile('name')) {
            $file = $request->file('name');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.'.$extension;
            $file->move('app/public/',$filename);
            $hireme->name = $filename;
        }
        else {
            return $request;
            $hireme->name='';
        }
        $hireme->rate=$request->get('rate');
        $hireme->input1=$request->get('input1');
        $hireme->input2=$request->get('input2');
        $hireme->input3=$request->get('input3');
        $hireme->input4=$request->get('input4');
        $hireme->save();
        return redirect('/hireme')->with('success', 'cart has inserted');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $hire = hireme::find($id);
        return view('hireme.edit',compact('hire','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $hireme = hireme::find($id);
          $hireme->rate=$request->get('rate');
          $hireme->input1=$request->get('input1');
          $hireme->input2=$request->get('input2');
          $hireme->input3=$request->get('input3');
          $hireme->input4=$request->get('input4');
          $hireme->save();
          return redirect('hireme');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $hireme= hireme::find($id);
        $hireme->delete();
        return redirect('hireme')->with('success','deleted successfully');
    }
}
