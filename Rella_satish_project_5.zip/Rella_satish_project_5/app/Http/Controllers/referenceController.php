<?php

namespace App\Http\Controllers;

use App\reference;

use Illuminate\Http\Request;

class referenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $references = reference::all()->toArray();
        return view('references.index', compact('references'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('references.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
         $reference= new reference();
        if($request->hasfile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.'.$extension;
            $file->move('app/public/',$filename);
            $reference->image = $filename;
        }
        else {
            return $request;
            $reference->image='';
        }
        $reference->name=$request->get('name');
         $reference->position=$request->get('position');
          $reference->description=$request->get('description');
        
       $reference->save();
        return redirect('/references')->with('success', 'Reference has inserted');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $references = reference::find($id);
        return view('references.edit',compact('references','id'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $references = reference::find($id);

        if ($request->hasfile('image')){
            
            $file=$request->file('image');
            $extension=$file->getClientOriginalExtension();
            $filename=time(). '.'. $extension;
            $file->move('app/public/',$filename);
            $references->image = $filename;
        }
          $references->name=$request->get('name');
          $references->position=$request->get('position');
          $references->description=$request->get('description');
          $references->save();
          return redirect('references');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $reference = reference::find($id);
        $reference->delete();
        return redirect('references')->with('success','reference has been  deleted');

    }
}
