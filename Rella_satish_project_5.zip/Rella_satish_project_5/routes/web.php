<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('portfolio','FormController');
Route::get('/index', function () {
    return view('index');
});
Route::get('/', function () {
    return view('welcome');
});
Auth::routes();
Route::view('/portfolio', 'index');
// Route::get('portfolio', function () {
//     return view('/');
// });
Route::resource('hireme','hiremeController');
Route::post('/hireme','hiremeController@store')->name('hireme');
Route::get('/hireme','hiremeController@index');
Route::post('hireme/{id}/edit','hiremeController@update');

Route::resource('skills','skillController');
Route::post('/skills','skillController@store')->name('skills');
Route::get('/skills','skillController@index');
Route::post('skills/{id}/edit','skillController@update');

Route::resource('resumes','resumeController');
Route::post('/resumes','resumeController@store')->name('resumes');
Route::get('/resumes','resumeController@index');
Route::post('resumes/{id}/edit','resumeController@update');

use Illuminate\Http\Request;
use App\Mail\ContactMail;
use Illuminate\Support\Facades\Mail;

Route::get('/contact', function () {
    return view('contact');
 });

Route::post('/contact', function(Request $request){

	Mail :: send(new ContactMail($request));

	return redirect('/contact');

});

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('references','referenceController');

Route::resource('about','aboutController');

// Route::get('/about', function () {
//     return view('/');
//  });
Route::get('/projects', function () {
    return view('projects');
 });

Route::get('/reference', function () {
    return view('reference');
 });