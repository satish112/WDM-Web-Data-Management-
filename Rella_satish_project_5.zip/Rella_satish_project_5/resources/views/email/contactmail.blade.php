{{ $email->name }}<br>
{{ $email->email }}<br>
{{ $email->phone }}<br>
{{ $email->content }}