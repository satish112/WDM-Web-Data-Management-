<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="./css/about.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">ABOUT ME</span>
</div>
</center>
    @if (\Session::has('success'))
      <div class="alert alert-success">
        <p>{{ \Session::get('success') }}</p>
      </div><br />
     @endif
@foreach ($abouts as $ab)
<br>
<br>
@if(Auth::user()->is_admin)
<a href="{{action('aboutController@edit', $ab['id'])}}" class="btn btn-warning"><button class="btn btn-danger" type="submit">Edit</button></a>
@endif
<div class="row">
  <div class="column left">
    <img src="app/public/{{$ab['image']}}"/ class ="image1">
    <p>Developer / 3D Design</p>
  </div>
  <div class ="column right">
    <div class ="child inline-block-child">
      <div class="wrapper">
        <i class="icon fa fa-user"></i>
        <span class="text">Name 
        <br>{{$ab['name']}}</span>
      </div>
      <div class="wrapper">
        <i class="icon fa fa-volume-control-phone"></i>
        <span class="text">Phone 
        <br>{{$ab['phone']}}</span>
      </div>
      <div class="wrapper">
        <i class="icon fa fa-map-marker"></i>
        <span class="text">Address 
        <br>{{$ab['address']}}</span>
      </div>  
    </div>
    <div class ="child inline-block-child">      
      <div class="wrapper">
        <i class="icon fa fa-envelope"></i>
        <span class="text">Email 
        <br>{{$ab['email']}}</span>
      </div>
      <div class="wrapper">
        <i class="icon fa fa-calendar"></i>
        <span class="text">Date Of Birthday 
        <br>{{$ab['dob']}}</span>
      </div>
      <div class="wrapper">
        <i class="icon fa fa-flag"></i>
        <span class="text">Nationality 
        <br>{{$ab['nationality']}}</span>
      </div>
    </div>
    <div class= "column2">
      <p> Social Profiles<a href="#" class="fa fa-facebook"></a>
      <a href="#" class="fa fa-twitter"></a>
      <a href="#" class="fa fa-linkedin"></a>
      <a href="#" class="fa fa-pinterest"></a>
      <a href="#" class="fa fa-google-plus"></a>
      <a href="#" class="fa fa-snapchat"></a></p> 
      <p> {{$ab['description']}}</p>
      <br>
      <p>Yours sincerely,</p>
        <img src="./images/twke3.PNG" class ="iamge1"style="width:200px;height:60px;">   
  </div>
  @endforeach
  <div class="arrow">
        <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
      </div>
</div>
</div>
<style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff);
    float: left;
}
button:hover {
    color: #222222;
}
</style>
</body>
</html>
