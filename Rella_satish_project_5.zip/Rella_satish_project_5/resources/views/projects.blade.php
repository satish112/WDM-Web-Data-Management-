<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/portfolio.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">PORTFOLIO</span>
</div>
<div class="topnav">
  <div class="topnav-centered">
    <a href="#demo" data-parent="#accordion" data-toggle="collapse">All</a>
    <a href="#demo1" data-parent="#accordion" data-toggle="collapse">Websites</a>
    <a href="#demo2" data-parent="#accordion" data-toggle="collapse">Apps</a>
    <a href="#demo3" data-parent="#accordion" data-toggle="collapse">Design</a>
    <a href="#demo4" data-parent="#accordion" data-toggle="collapse">Photography</a>
</div>
<div class="panel-group" id="accordion">
<div class="panel panel-default">
<div id="demo" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
  <div class="column">
    <img src="./images/asgardia.png" width="400px" height="250px" />
    <img src="./images/1.jpg" width="400px" height="600px"/>
    <img src="./images/app8.png" width="400px" height="600px"/>
    <img src="./images/app5.png" width="400px" height="600px"/>
  </div>
  <div class="column">
    <img src="./images/dise11.jpg" width="400px" height="400px" />
    <img src="./images/app9.png" width="400px" height="700px"/>
    <img src="./images/app7.png" width="400px" height="700px"/>
    <img src="./images/player.png" width="400px" height="250px"/>
  </div>
  <div class="column">
    <img src="./images/16.jpg" width="400px" height="650px" />
    <img src="./images/dise4.png" width="410px" height="450px"/>
    <img src="./images/9.jpg" width="400px" height="600px"/>
    <img src="./images/dise5.png" width="400px" height="250px"/>
    <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>
</div>
</div>
</div>
<div class="panel panel-default">
<div id="demo1" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
  <div class="column">
    <img src="./images/asgardia.png" width="400px" height="250px" />
  </div>
  <div class="column">
    <img src="./images/player.png" width="400px" height="250px"/>
  </div>
    <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>
</div>
</div>
<div class="panel panel-default">
<div id="demo2" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
  <div class="column">
    <img src="./images/app8.png" width="400px" height="600px"/>
    <img src="./images/app5.png" width="400px" height="600px"/>
  </div>
  <div class="column">
    <img src="./images/app9.png" width="400px" height="700px"/>
    <img src="./images/app7.png" width="400px" height="700px"/>
  </div>
  <div class="column">
    <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>
</div>
</div>
</div>
<div class="panel panel-default">
<div id="demo3" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
  <div class="column">
    <img src="./images/dise11.jpg" width="400px" height="400px" />
  </div>
  <div class="column">
    <img src="./images/dise4.png" width="410px" height="450px"/>
    <img src="./images/dise5.png" width="400px" height="250px"/>
    <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>
</div>
</div>
</div>
<div class="panel panel-default">
<div id="demo4" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
  <div class="column">
    <img src="./images/1.jpg" width="400px" height="600px"/>
  </div>
  <div class="column">
    <img src="./images/16.jpg" width="400px" height="650px" />
    <img src="./images/9.jpg" width="400px" height="600px"/>
    <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
  </div>
</div>
</div>
</div>
</div>
</div>

