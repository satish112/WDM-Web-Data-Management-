<!DOCTYPE html>
<html>
<head><meta http-equiv ="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="./css/skills.css">
<link rel="stylesheet" type="text/css" href="./css/circle.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">SKILLS</span>
</div>
</center>
<br>
@if(Auth::user()->is_admin)
<label for="text"><b>Do you want to Insert...?</b></label>
<a href="{{action('skillController@create')}}" class="btn btn-warning"><button class="btn btn-danger" type="submit">Insert</button></a>
@endif
<div class="row">
  @foreach ($skills as $skill)
        <div align="left">
   <div class="completion-bar">
   <div class="progress-bar" style="width:{{ $skill ->skillpercentage}};background-color:{{ $skill -> skillcolor}}"> <i class="{{ $skill ->skillicon}}"></i> {{ $skill ->skillname}}</div>
   <div class="progress_value">{{ $skill ->skillpercentage}}</div>
   </div>
   @if(Auth::user()->is_admin)
   <a href="{{action('skillController@edit', $skill['id'])}}" class="btn btn-warning"><button class="btn btn-danger" type="submit" id="button1">Edit</button></a>
    
   <form action="{{action('skillController@destroy', $skill['id'])}}" method="post">
            {{csrf_field()}}
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit" id="button2">Delete</button>
          </form>
    @endif
        </div>
   @endforeach
 </div>
 <style>
.progress-bar
{
    padding: 0.lem 16px;
    border-radius: 0px;
    color: #fff;
	height: 25px;
    background-color: #4b4fe2;
	
}
.completion-bar
{
    background-color: #f5f5f5;
    border-radius: 0px;
	height: 25px;
	margin-top: 15px;
	
}
.progress_value{
        		position: relative;
        		float: right;
        		padding-right: 1px;
        		line-height: 2.5;
        		font-weight: bolder;
				font-size: 16px;
        		color: #455a64;
        		margin-top: -33px;
				margin-right: 0px;
}
.column {
  float: left;
  width: 50%;
  height: 280px; 
  box-sizing: border-box;
  padding-left: 30px;
}

.row {
padding-top: 80px;
}
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff);

}
button:hover {
    color: #222222;
}
</style>
<div class="arrow">
        <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
      </div>
</center>
</body>
</html>
