<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/home.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
</head>
<body>
	<div id="sidebar">
		<center> <img src="./images/logo.png"/> </center>
		<center> <img src="./images/name.jpeg"/> </center>
  		<ul>
			<li><a style="color:white" href="adminhome.php">HOME</a></li>
			<li><a style="color:white" href="modifyabout.php">MODIFY ABOUT</a></li>
			<li><a style="color:white" href="modifyskills.php">MODIFY SKILLS</a></li>
			<li><a style="color:white" href="modifyresume.php">MODIFY RESUMES</a></li>
			<li><a style="color:white" href="modifyhire.php">MODIFY HIRE-ME</a></li>
		<?php if ($_SESSION['username'] == $username) : ?>
			<li><a style="color:white" href="logout.php">LOGOUT</a></li>
			<?php else : ?> 
			<li><a style="color:white" href="login.html	"></i>LOG IN</a></li>
			<li><a style="color:white" href="signup.html">SIGN UP</a></li>
			<?php endif;?>
			<p style="font-size: 12px; color: white"> &#169; DiazApps ALL RIGHTS RESERVED BY<span style="color: blue; font-size: 12px">Luis M Alvarez</span></p>
		</ul>
	</div>
	<div class="bg" style="float:right; width:85% ">
  		<div id="content">
    		<p style="font-size:35px; padding-left:80px;">HELLO</p>
    		<p style="font-size:70px; padding-left:80px;">LUIS MIGUEL ALVAREZ</p>
    		<p style="font-size:35px; padding-left:80px;">MOBILE DEVELOPER</p>
    		<form action="adminhome.php" method="post" enctype="multipart/form-data" >
    		<button class="btn" style="position: absolute; left: 80px;" type="submit" name="save"> Upload files <i class="fa fa-upload"></i></button>
    		<input type="file" name="myfile" style="padding:30px; padding-left:80px">
    	   </form>

    		<style>
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
</style>
  		</div>
	</div>
</body>
</html>
