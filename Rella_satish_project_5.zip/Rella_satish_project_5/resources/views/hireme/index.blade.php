<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<center>
<div class="topbar" >
  <span class ="topbar">HIRE ME</span>
</div>
<div class="table"> 
    <div class="row">
      @foreach ($hires as $hireme)
        <div class="column">
                <img src="{{ url('app/public/' .$hireme->name)}}" alt="{{$hireme ->name}}" class="img-responsive" >
                    <h2>{{ $hireme ->rate}}</h2>
                <p>{{ $hireme ->input1}}<br/> {{ $hireme ->input2}}<br/> {{ $hireme ->input3}}<br/> {{ $hireme ->input4}}</p>
	            <hr>
              <a href="{{ url('/contact') }}"><button class="btn">Contact Us</button></a>
              @if(Auth::user()->is_admin)
              <a href="{{action('hiremeController@edit', $hireme['id'])}}" class="btn btn-warning"><button class="btn btn-danger" type="submit">Edit</button></a>
	       <form action="{{action('hiremeController@destroy', $hireme['id'])}}" method="post">
            {{csrf_field()}}
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">Delete</button>
            @endif
          </form>
         </div>
         @endforeach
    </div>
</div>
@if(Auth::user()->is_admin)
<label for="text"><b>Do you want to Insert...?</b></label>
<a href="{{action('hiremeController@create')}}" class="btn btn-warning"><button class="btn btn-danger" type="submit">Insert</button></a>
@endif
<div class="arrow">
<a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
</div>
<style>
.topbar {
width: 95%;
height: 10px; 
border-bottom: 1px solid #D0D0D0; 
text-align: center;  
padding-top: 25px;  
}
.topbar span{
  font-size: 15px;
  background-color: white;
  border: 2px solid #0066FF; 
  padding: 10px 20px;
  
}
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}
.table{
        display: table;         
  width: auto; 
border-spacing: 50px;  
}
.column {
  float: left;
  width: 33.33%;
  height:600px;
  display:table-column;     
}
.column img {
height: 180px;
width: 350px;
}
.row {
padding-top: 80px;
display: table-row;
  width: auto;
  clear: both;
}
.arrow{
  width: auto;
  height: auto; 
  padding-left:auto;
  padding-top: auto;
}
.fa-arrow-up {
  font-size: 20px;
  background: black;
  color: blue;
   padding:10px;
   padding-right: 10px;
   padding-left: 10px;
}
</style>
</body>
</html>