<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/reference.css">
</head>
<body>
@if(Auth::user()->is_admin)
<label for="text"><b>Do you want to Insert...?</b></label>
<a href="{{action('referenceController@create')}}" class="btn btn-warning"><button class="btn btn-danger" type="submit">Insert</button></a>
@endif
<center>
<div style="width: 100%; height: 10px; border-bottom: 1px solid #D0D0D0; text-align: center;  padding-top: 25px;" >
  <span style="font-size: 15px; background-color: white; border: 2px solid #0066FF; padding: 10px 20px;">
    REFERENCES
  </span>
</div>
@foreach ($references as $refer)
<div class="row">
  <div class="column">
    <div id = "border">
      <img src="app/public/{{$refer['image']}}" alt="Avatar" width="50" height="50" align="center" >
      <h4>{{$refer['name']}}</h4>
      <h6>{{$refer['position']}}
        @if(Auth::user()->is_admin)<form action="{{action('referenceController@destroy', $refer['id'])}}" method="post">
            {{csrf_field()}}
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit" id="button2">Delete</button>
          </form>@endif</h6>
         
      <p>{{$refer['description']}}
      @if(Auth::user()->is_admin)
      <a href="{{action('referenceController@edit', $refer['id'])}}" class="btn btn-warning"><button class="btn btn-danger" type="submit" id="button1">Edit</button></a>
      @endif
    </p>
    </div>    
  </div>
</div>
@endforeach
</center>
<style>
  button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff);

}
button:hover {
    color: #222222;
}
</style>
<div class="arrow">
        <a href="{{ url('/index') }}"><i class="icon fa fa-arrow-up"></i></a>
      </div>
</body>
</html>

