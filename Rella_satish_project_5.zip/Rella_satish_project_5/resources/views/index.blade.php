<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="./css/home.css">
<link rel="stylesheet" type="text/css" href="./css/portfile.css">
</head>
<body>
	<div id="sidebar">
		<center> <img src="./images/logo.png"/> </center>
		<center> <img src="./images/name.jpeg"/> </center>
  		<ul>
  			@if (Route::has('login'))
  			@auth
				<li><a style="color:white" href="{{ url('/index') }}">HOME</a></li>
				<li><a style="color:white" href="{{ url('/about') }}">ABOUT</a></li>
				<li><a style="color:white" href="{{ url('/skills') }}">SKILLS</a></li>
				<li><a style="color:white" href="{{ url('/resumes') }}">RESUMES</a></li>
				<li><a style="color:white" href="{{ url('/projects') }}">PORTFOLIO</a></li>
				<li><a style="color:white" href="http://satishrella.uta.cloud/porject-2/">BLOG</a></li>
				<li><a style="color:white" href="{{ url('/hireme') }}">HIRE ME</a></li>
				<li><a style="color:white" href="{{ url('/references') }}">REFERENCES</a></li>
				<li class="nav-item dropdown">
                                
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                	<a href="#" role="button" aria-haspopup="true" style="color:white" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="charset"></span>
                                </a> 

                                    <a style="color:white" class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
			@else
			<li><a style="color:white" href="{{ route('login') }}"></i>LOG IN</a></li>
				@if (Route::has('register'))
					<li><a style="color:white" href="{{ route('register') }}">SIGN UP</a></li>
				@endif
			@endauth
			@endif
			<p style="font-size: 12px; color: white"> &#169; DiazApps ALL RIGHTS RESERVED BY<span style="color: blue; font-size: 12px">Luis M Alvarez</span></p>
		</ul>
	</div>
	<div class="bg" style="float:right; width:85% ">
  		<div id="content">
    		<p style="font-size:35px; padding-left:80px;">HELLO I'M</p>
    		<p style="font-size:70px; padding-left:80px;">LUIS MIGUEL ALVAREZ</p>
    		<p style="font-size:35px; padding-left:80px;">MOBILE DEVELOPER</p>
    		 @if(Auth::user())
    		<button class="btn" style="position: absolute; left: 80px;" type="submit" name="download"><a style="text-decoration-color:none; color: black; padding: 0px 35px;" href="RSRESUME.pdf" download>Download My Cv</a><i class="fa fa-download"></i></button>
    		@endif

    		<style> 
button{
background-size: 200% auto;
    padding: 0px 35px;
    color: #222222;
    background: linear-gradient(to right,#3fcaff 0%,#a4ffb0 51%,#3fcaff)
}
button:hover {
    color: #222222;
}

</style>
  		</div>
	</div>
</body>
</html>
